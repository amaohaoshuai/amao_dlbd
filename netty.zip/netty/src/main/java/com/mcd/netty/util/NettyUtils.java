package com.mcd.netty.util;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.CharsetUtil;

public class NettyUtils {

    public static final String WRITE_SUCCESS_MSG =  "received success";

    public static final String WRITE_FAIL_MSG = "received fail";


    public static String[] splitMsg(Object msg, String regex) {

        ByteBuf byteBuf = (ByteBuf) msg;
        String message = ((ByteBuf) msg).toString(CharsetUtil.UTF_8);

        if ("".equals(message) || message == null) {
            return null;
        }
        return message.split(regex);
    }

    public static void write(ChannelHandlerContext ctx, String msg) {
        ctx.write(
                ctx.alloc().buffer(4 * msg.length())
                .writeBytes(msg.getBytes())
        );
        ctx.flush();
    }

}
