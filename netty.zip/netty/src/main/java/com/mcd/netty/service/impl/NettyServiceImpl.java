package com.mcd.netty.service.impl;

import com.mcd.netty.entity.Message;
import com.mcd.netty.service.NettyService;
import org.springframework.stereotype.Service;

@Service
public class NettyServiceImpl implements NettyService {
    public static Message message = new Message();

    @Override
    public void setMessage(String msg) {
        message.setMessage(msg);
    }

    @Override
    public String getMessage() {
        return message.getMessage();
    }
}
