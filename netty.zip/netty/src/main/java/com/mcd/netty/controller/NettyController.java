package com.mcd.netty.controller;

import com.mcd.netty.service.NettyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/netty")
public class NettyController {

    @Autowired
    private NettyService nettyService;

    @RequestMapping(value = "/getMessage")
    public Map<String,Object> getMessage(){
        Map<String,Object> modelMap = new HashMap<>();
        modelMap.put("message", nettyService.getMessage());
        return modelMap;
    }

}
