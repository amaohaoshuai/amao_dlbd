package com.mcd.netty.entity;

import lombok.Data;

@Data
public class Message {

    private String message;
}
