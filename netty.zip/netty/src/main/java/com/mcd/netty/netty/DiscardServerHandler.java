package com.mcd.netty.netty;

import com.mcd.netty.service.NettyService;
import com.mcd.netty.util.NettyUtils;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.ReferenceCountUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@ChannelHandler.Sharable
public class DiscardServerHandler extends ChannelHandlerAdapter {

    @Autowired
    private NettyService nettyService;

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {

        try {
//
            // 1. 数据根据分隔符拆分
            String[] dataArray = NettyUtils.splitMsg(msg, ",");
            if (dataArray == null) {
                NettyUtils.write(ctx, NettyUtils.WRITE_FAIL_MSG);
            }
            for (String s : dataArray) {
                System.out.println(s);
            }
            // 2. 绑定对象
            // 3. 存储数据,存储成功返回客户端消息

            //这里调用service服务
//            baseService.setMessage(in.toString(CharsetUtil.UTF_8));

        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            ReferenceCountUtil.release(msg);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        // 出现异常就关闭
        cause.printStackTrace();
        ctx.close();
    }


}
