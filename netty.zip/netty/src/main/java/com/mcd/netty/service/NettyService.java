package com.mcd.netty.service;

public interface NettyService {

    void setMessage(String message);

    String getMessage();
}
